package com.Ebook.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
