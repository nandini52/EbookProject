package com.Ebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookApplication.class, args);
		System.out.println("con..");
	}

}
//http://localhost:9090/swagger-ui/index.html
//http://localhost:8081/swagger-ui.html