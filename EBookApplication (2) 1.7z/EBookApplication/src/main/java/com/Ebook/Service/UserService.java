package com.Ebook.Service;

import com.Ebook.Entity.User;

public interface UserService {
	User addUser(User user);

}
